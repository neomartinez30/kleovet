import React from 'react';
import KleoVet from './KleoVet';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <KleoVet />
    </div>
  );
}

export default App;