import React, { useState, useEffect } from 'react';
import { 
  Search, 
  ChevronRight, 
  Bell, 
  Calendar, 
  Video, 
  MessageSquare, 
  FileText, 
  Home, 
  Settings, 
  LogOut, 
  PlusCircle, 
  Users, 
  Database,
  Building,
  Shield,
  LogIn,
  Mic,
  MicOff,
  Phone,
  MessageCircle,
  Activity,
  Thermometer,
  Clipboard,
  Pill,
  Plus,
  Filter,
  ArrowLeft
} from 'lucide-react';

const KleoVet = () => {
  // Main application state
  const [currentView, setCurrentView] = useState('login');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [selectedAppointment, setSelectedAppointment] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentClinic, setCurrentClinic] = useState(null);
  const [filter, setFilter] = useState('all');
  const [aiTranscription, setAiTranscription] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [currentTab, setCurrentTab] = useState('patient-info');

  // Handle window resize for responsive design
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  // Extract clinic ID from URL or default to login screen
  useEffect(() => {
    // In a real app, this would parse the URL or check localStorage
    const urlParams = new URLSearchParams(window.location.search);
    const clinicId = urlParams.get('clinic');
    
    if (clinicId) {
      const clinic = clinicsList.find(c => c.id === clinicId);
      if (clinic) {
        setCurrentClinic(clinic);
      }
    }

    // Auto-login for demo purposes - remove for production
    // setIsLoggedIn(true);
    // setCurrentView('appointments');
  }, []);

  // Clinic data
  const clinicsList = [
    { 
      id: 'pawsitively', 
      name: 'Pawsitively Pets Veterinary Clinic', 
      logo: '/api/placeholder/200/50', 
      primaryColor: '#36B2DC', 
      secondaryColor: '#E0F2FE'
    },
    { 
      id: 'cityvet', 
      name: 'City Veterinary Hospital', 
      logo: '/api/placeholder/200/50', 
      primaryColor: '#1E88E5',
      secondaryColor: '#E3F2FD'
    },
    { 
      id: 'carefirst', 
      name: 'Care First Animal Hospital', 
      logo: '/api/placeholder/200/50', 
      primaryColor: '#5C6BC0',
      secondaryColor: '#E8EAF6'
    },
    { 
      id: 'allpaws', 
      name: 'All Paws Veterinary Clinic', 
      logo: '/api/placeholder/200/50', 
      primaryColor: '#3949AB',
      secondaryColor: '#E8EAF6'
    }
  ];

  // Handle login submission
  const handleLogin = (credentials, clinicId) => {
    // In a real app, this would validate credentials against an API
    console.log('Login attempt:', credentials, 'for clinic:', clinicId);
    
    // Mock successful login
    if (clinicId) {
      const clinic = clinicsList.find(c => c.id === clinicId);
      if (clinic) {
        setCurrentClinic(clinic);
        setIsLoggedIn(true);
        setCurrentView('dashboard');
      }
    }
  };

  // The appointments data used in the dashboard and appointments views
  const allAppointments = [
    { id: 1, name: 'Max', species: 'Dog', breed: 'Golden Retriever', owner: 'John Smith', doctor: 'Dr. Roberts', time: '9:30 AM', type: 'Surgery', reason: 'Dental cleaning' },
    { id: 2, name: 'Bella', species: 'Dog', breed: 'German Shepherd', owner: 'Sarah Johnson', doctor: 'Dr. Chen', time: '10:30 AM', type: 'Telehealth', reason: 'Follow-up consultation' },
    { id: 3, name: 'Charlie', species: 'Cat', breed: 'Tabby', owner: 'Michael Brown', doctor: 'Dr. Roberts', time: '11:15 AM', type: 'In-person', reason: 'Annual check-up' },
    { id: 4, name: 'Luna', species: 'Dog', breed: 'Labrador', owner: 'Emily Wilson', doctor: 'Dr. Chen', time: '1:00 PM', type: 'Surgery', reason: 'Mass removal' },
    { id: 5, name: 'Cooper', species: 'Cat', breed: 'Maine Coon', owner: 'Robert Taylor', doctor: 'Dr. Roberts', time: '2:30 PM', type: 'Telehealth', reason: 'Medication review' },
    { id: 6, name: 'Bailey', species: 'Dog', breed: 'Shih Tzu', owner: 'Jennifer Lee', doctor: 'Dr. Chen', time: '3:45 PM', type: 'In-person', reason: 'Skin condition' },
    { id: 7, name: 'Oliver', species: 'Cat', breed: 'Siamese', owner: 'Daniel Martinez', doctor: 'Dr. Roberts', time: '4:15 PM', type: 'In-person', reason: 'Respiratory issue' },
    { id: 8, name: 'Daisy', species: 'Dog', breed: 'Poodle', owner: 'Amanda Clark', doctor: 'Dr. Chen', time: '5:00 PM', type: 'Telehealth', reason: 'Dietary consultation' }
  ];

  // Navigation handler
  const handleTabClick = (tabId) => {
    setActiveTab(tabId);
    setCurrentView(tabId);
    setSelectedAppointment(null);
  };

  // Start voice dictation in appointment detail page
  const startVoiceDictation = () => {
    setIsRecording(true);
    
    // Simulate AI transcription after a delay
    setTimeout(() => {
      setAiTranscription({
        transcription: `Dr: Hello, how is ${selectedAppointment.name} doing today?\nOwner: ${selectedAppointment.name} has been ${selectedAppointment.reason.toLowerCase() === 'annual check-up' ? 'doing well overall, just here for the regular checkup' : 'having some issues with ' + selectedAppointment.reason.toLowerCase()}.\nDr: I see. Let's take a look and run some tests to get a better understanding.`,
        summary: {
          highlevel: `${selectedAppointment.name} presented for ${selectedAppointment.reason.toLowerCase()}. Owner reports ${selectedAppointment.reason.toLowerCase() === 'annual check-up' ? 'no significant concerns' : 'concerns related to ' + selectedAppointment.reason.toLowerCase()}.`,
          detailed: `${selectedAppointment.name}, a ${selectedAppointment.breed}, presented for ${selectedAppointment.reason.toLowerCase()}. Physical examination revealed ${selectedAppointment.reason.toLowerCase() === 'annual check-up' ? 'all vitals within normal limits.' : 'abnormalities consistent with ' + selectedAppointment.reason.toLowerCase() + '. Further diagnostics recommended.'}`,
        },
        diagnoses: [
          selectedAppointment.reason.toLowerCase() === 'annual check-up' ? 'Healthy adult animal' : `Possible ${selectedAppointment.reason}`,
          selectedAppointment.reason.toLowerCase() === 'annual check-up' ? 'Preventative care maintained' : 'Monitoring recommended'
        ]
      });
      setIsRecording(false);
    }, 3000);
  };

  // Stop voice dictation
  const stopVoiceDictation = () => {
    setIsRecording(false);
  };

  // Get AI recommendations based on appointment reason
  const getAiRecommendations = () => {
    if (!selectedAppointment) return [];
    
    const reasonMap = {
      'Dental cleaning': [
        'Pre-anesthetic bloodwork recommended',
        'Check previous dental chart for comparison',
        'Prepare dental radiographs equipment',
        'Consider post-procedure antibiotics if extractions needed'
      ],
      'Follow-up consultation': [
        'Review previous treatment efficacy',
        'Assess for side effects from prescribed medications',
        'Determine if continued treatment is necessary',
        'Consider bloodwork to monitor organ function'
      ],
      'Annual check-up': [
        'Update vaccinations as needed',
        'Perform heartworm test',
        'Assess dental health',
        'Discuss preventative care options'
      ],
      'Mass removal': [
        'Pre-anesthetic bloodwork essential',
        'Plan for histopathology submission',
        'Discuss post-op care with owner',
        'Consider pain management protocol'
      ],
      'Medication review': [
        'Check kidney and liver values',
        'Assess efficacy of current medication',
        'Review for potential drug interactions',
        'Consider long-term maintenance options'
      ],
      'Skin condition': [
        'Perform skin scraping to check for mites',
        'Consider fungal culture',
        'Evaluate for possible allergic dermatitis',
        'Review diet for potential food allergies'
      ],
      'Respiratory issue': [
        'Auscultate all lung fields thoroughly',
        'Consider chest radiographs',
        'Check for nasal discharge',
        'Assess for heart murmur as potential cause'
      ],
      'Dietary consultation': [
        'Review current diet composition',
        'Calculate caloric requirements',
        'Check for food sensitivities in history',
        'Provide gradual transition protocol for new diet'
      ]
    };
    
    return reasonMap[selectedAppointment.reason] || [
      'Complete full physical examination',
      'Review patient history for relevant patterns',
      'Consider diagnostic testing if condition persists',
      'Document findings thoroughly for follow-up care'
    ];
  };

  // Login Form Component
  const LoginForm = ({ clinicData, onLogin }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    
    const handleSubmit = (e) => {
      e.preventDefault();
      if (!email || !password) {
        setError('Please enter both email and password');
        return;
      }
      
      onLogin({ email, password }, clinicData?.id);
    };
    
    return (
      <div className="bg-white rounded-lg shadow-lg p-8 max-w-md w-full">
        <div className="flex justify-center mb-6">
          {clinicData && clinicData.logo ? (
            <img src={clinicData.logo} alt={`${clinicData.name} Logo`} className="h-12" />
          ) : (
            <img src="/api/placeholder/200/50" alt="KleoVet Logo" className="h-12" />
          )}
        </div>
        
        <h2 className="text-2xl font-bold text-center mb-2" style={clinicData ? { color: clinicData.primaryColor } : { color: '#36B2DC' }}>
          {clinicData ? `${clinicData.name}` : 'KleoVet Platform'}
        </h2>
        <p className="text-gray-600 text-center mb-6">Log in to your account</p>
        
        {error && <div className="bg-red-100 text-red-700 p-3 rounded mb-4">{error}</div>}
        
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-medium mb-2">Email Address</label>
            <input
              type="email"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="mb-6">
            <label className="block text-gray-700 text-sm font-medium mb-2">Password</label>
            <input
              type="password"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button
            type="submit"
            className="w-full py-2 px-4 rounded-lg text-white font-medium flex items-center justify-center"
            style={clinicData ? { backgroundColor: clinicData.primaryColor } : { backgroundColor: '#36B2DC' }}
          >
            <LogIn size={18} className="mr-2" />
            Log In
          </button>
        </form>
        
        <div className="mt-6 flex items-center justify-between">
          <div className="text-sm">
            <a href="#" className="text-blue-600 hover:underline">Forgot password?</a>
          </div>
          <div className="text-sm">
            <a href="#" className="text-blue-600 hover:underline">Need help?</a>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t text-center">
          <p className="text-sm text-gray-600">
            Powered by <span className="font-semibold">KleoVet</span> - Veterinary Telemedicine Platform
          </p>
        </div>
      </div>
    );
  };
  
  // Clinic Selection Component
  const ClinicSelector = ({ clinics, onSelectClinic }) => {
    return (
      <div className="bg-white rounded-lg shadow-lg p-8 max-w-md w-full">
        <div className="flex justify-center mb-6">
          <img src="/api/placeholder/200/50" alt="KleoVet Logo" className="h-12" />
        </div>
        
        <h2 className="text-2xl font-bold text-center text-blue-950 mb-2">Select Your Clinic</h2>
        <p className="text-gray-600 text-center mb-6">Choose your veterinary clinic to continue</p>
        
        <div className="space-y-3">
          {clinics.map(clinic => (
            <button
              key={clinic.id}
              className="w-full p-4 border border-gray-200 rounded-lg hover:bg-gray-50 flex items-center"
              onClick={() => onSelectClinic(clinic)}
            >
              <Building size={20} className="mr-3 text-blue-500" />
              <span className="font-medium">{clinic.name}</span>
            </button>
          ))}
        </div>
        
        <div className="mt-8 pt-6 border-t">
          <p className="text-sm text-gray-600 text-center">
            Don't see your clinic? <a href="#" className="text-blue-600 hover:underline">Contact support</a>
          </p>
        </div>
      </div>
    );
  };
  
  // Login Page Component
  const LoginPage = () => {
    const [selectedClinic, setSelectedClinic] = useState(currentClinic);
    
    const handleSelectClinic = (clinic) => {
      setSelectedClinic(clinic);
    };
    
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col justify-center items-center p-4">
        <div className="mb-6 flex items-center">
          <Shield size={24} className="text-blue-600 mr-2" />
          <span className="text-gray-500">Secure Login</span>
        </div>
        
        {selectedClinic ? (
          <LoginForm clinicData={selectedClinic} onLogin={handleLogin} />
        ) : (
          <ClinicSelector clinics={clinicsList} onSelectClinic={handleSelectClinic} />
        )}
        
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500">
            Are you a new clinic? <a href="#" className="text-blue-600 hover:underline">Contact us to get started</a>
          </p>
        </div>
      </div>
    );
  };

  // Sidebar component for the main application
  const Sidebar = () => (
    <aside className="bg-white border-r border-gray-200 w-64 flex flex-col h-full" style={{ backgroundColor: currentClinic ? currentClinic.secondaryColor : '#E0F2FE' }}>
      <div className="p-4 flex justify-center border-b">
        {currentClinic && currentClinic.logo ? (
          <img src={currentClinic.logo} alt={`${currentClinic.name} Logo`} className="h-10" />
        ) : (
          <img src="/api/placeholder/150/40" alt="KleoVet Logo" className="h-10" />
        )}
      </div>
      <div className="p-4">
        <button 
          className="w-full py-2 rounded-lg font-medium flex items-center justify-center text-white"
          style={{ backgroundColor: currentClinic ? currentClinic.primaryColor : '#36B2DC' }}
          onClick={() => alert('Creating new appointment')}
        >
          <PlusCircle className="h-5 w-5 mr-2" />
          New Appointment
        </button>
      </div>
      <nav className="flex-1">
        <ul>
          <li>
            <button
              className={`flex items-center space-x-3 px-4 py-3 w-full text-left hover:bg-gray-100 ${activeTab === 'dashboard' ? 'bg-blue-50 border-r-4 border-blue-500' : 'text-gray-700'}`}
              onClick={() => handleTabClick('dashboard')}
            >
              <span className={activeTab === 'dashboard' ? 'text-blue-500' : 'text-gray-500'}>
                <Home className="h-5 w-5" />
              </span>
              <span className="font-medium">Dashboard</span>
            </button>
          </li>
          <li>
            <button
              className={`flex items-center space-x-3 px-4 py-3 w-full text-left hover:bg-gray-100 ${activeTab === 'appointments' ? 'bg-blue-50 border-r-4 border-blue-500' : 'text-gray-700'}`}
              onClick={() => handleTabClick('appointments')}
            >
              <span className={activeTab === 'appointments' ? 'text-blue-500' : 'text-gray-500'}>
                <Calendar className="h-5 w-5" />
              </span>
              <span className="font-medium">Appointments</span>
            </button>
          </li>
          <li>
            <button
              className={`flex items-center space-x-3 px-4 py-3 w-full text-left hover:bg-gray-100 ${activeTab === 'patients' ? 'bg-blue-50 border-r-4 border-blue-500' : 'text-gray-700'}`}
              onClick={() => handleTabClick('patients')}
            >
              <span className={activeTab === 'patients' ? 'text-blue-500' : 'text-gray-500'}>
                <Users className="h-5 w-5" />
              </span>
              <span className="font-medium">Patients</span>
            </button>
          </li>
          <li>
            <button
              className={`flex items-center space-x-3 px-4 py-3 w-full text-left hover:bg-gray-100 ${activeTab === 'telehealth' ? 'bg-blue-50 border-r-4 border-blue-500' : 'text-gray-700'}`}
              onClick={() => handleTabClick('telehealth')}
            >
              <span className={activeTab === 'telehealth' ? 'text-blue-500' : 'text-gray-500'}>
                <Video className="h-5 w-5" />
              </span>
              <span className="font-medium">Telehealth</span>
            </button>
          </li>
          <li>
            <button
              className={`flex items-center space-x-3 px-4 py-3 w-full text-left hover:bg-gray-100 ${activeTab === 'messages' ? 'bg-blue-50 border-r-4 border-blue-500' : 'text-gray-700'}`}
              onClick={() => handleTabClick('messages')}
            >
              <span className={activeTab === 'messages' ? 'text-blue-500' : 'text-gray-500'}>
                <MessageSquare className="h-5 w-5" />
              </span>
              <span className="font-medium">Messages</span>
            </button>
          </li>
          <li>
            <button
              className={`flex items-center space-x-3 px-4 py-3 w-full text-left hover:bg-gray-100 ${activeTab === 'health-certs' ? 'bg-blue-50 border-r-4 border-blue-500' : 'text-gray-700'}`}
              onClick={() => handleTabClick('health-certs')}
            >
              <span className={activeTab === 'health-certs' ? 'text-blue-500' : 'text-gray-500'}>
                <FileText className="h-5 w-5" />
              </span>
              <span className="font-medium">Health Certificates</span>
            </button>
          </li>
          <li>
            <button
              className={`flex items-center space-x-3 px-4 py-3 w-full text-left hover:bg-gray-100 ${activeTab === 'records' ? 'bg-blue-50 border-r-4 border-blue-500' : 'text-gray-700'}`}
              onClick={() => handleTabClick('records')}
            >
              <span className={activeTab === 'records' ? 'text-blue-500' : 'text-gray-500'}>
                <Database className="h-5 w-5" />
              </span>
              <span className="font-medium">Records</span>
            </button>
          </li>
        </ul>
      </nav>
      <div className="p-4 border-t">
        <button 
          className="w-full py-2 rounded-lg font-medium flex items-center justify-center text-gray-700 border border-gray-300 hover:bg-gray-100"
          onClick={() => {
            setIsLoggedIn(false);
            setCurrentView('login');
          }}
        >
          <LogOut className="h-5 w-5 mr-2" />
          Log Out
        </button>
      </div>
    </aside>
  );
  
  // Header component for the main application
  const Header = () => (
    <header className="bg-white border-b border-gray-200 px-4 py-3 flex justify-between items-center" style={{ backgroundColor: currentClinic ? currentClinic.secondaryColor : '#E0F2FE' }}>
      <div className="flex items-center space-x-4">
        <h1 className="text-xl font-bold" style={{ color: currentClinic ? currentClinic.primaryColor : '#36B2DC' }}>
          {currentClinic ? currentClinic.name : 'KleoVet'}
        </h1>
        <div className="relative">
          <input
            type="text"
            placeholder="Search patients, records..."
            className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
        </div>
      </div>
      <div className="flex items-center space-x-3">
        <div className="relative">
          <Bell className="h-6 w-6 text-gray-500 cursor-pointer" />
          <span className="absolute top-0 right-0 h-2 w-2 bg-red-500 rounded-full"></span>
        </div>
        <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white">
          <span className="font-medium">D</span>
        </div>
        <div>
          <span className="font-medium text-gray-700">Dr. Roberts</span>
        </div>
      </div>
    </header>
  );

  // Dashboard component - main landing page
  const Dashboard = () => {
    // Dashboard stats for quick overview
    const dashboardStats = [
      { title: 'Appointments Today', value: '8', change: '+2', trend: 'up' },
      { title: 'Telehealth Sessions', value: '3', change: '+1', trend: 'up' },
      { title: 'Health Certs Pending', value: '2', change: '0', trend: 'neutral' },
      { title: 'Messages Unread', value: '5', change: '-3', trend: 'down' }
    ];

    // Recent health certificates for dashboard display
    const recentHealthCerts = [
      { id: 1, pet: 'Max', type: 'Interstate Travel', destinations: 'CA to OR', date: 'May 10, 2025', status: 'Completed' },
      { id: 2, pet: 'Luna', type: 'International Travel', destinations: 'US to Canada', date: 'May 8, 2025', status: 'Completed' },
      { id: 3, pet: 'Charlie', type: 'Interstate Travel', destinations: 'NY to FL', date: 'May 5, 2025', status: 'Processing' }
    ];

    // Upcoming appointments for dashboard
    const upcomingAppointments = allAppointments.slice(0, 4);

    return (
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl font-semibold text-gray-800 mb-6">
          Dashboard - {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </h1>

        {/* Stats overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          {dashboardStats.map((stat, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-gray-500 text-sm">{stat.title}</h2>
              <div className="flex items-end mt-2">
                <span className="text-3xl font-bold text-gray-800">{stat.value}</span>
                <span className={`ml-2 text-sm font-medium ${
                  stat.trend === 'up' ? 'text-green-600' : 
                  stat.trend === 'down' ? 'text-red-600' : 'text-gray-500'
                }`}>
                  {stat.change}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Upcoming appointments */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow overflow-hidden mb-6">
              <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-lg font-semibold text-gray-800">Today's Appointments</h2>
                <button 
                  className="text-blue-600 text-sm flex items-center"
                  onClick={() => handleTabClick('appointments')}
                >
                  View All <ChevronRight size={16} />
                </button>
              </div>
              <div className="p-6">
                {upcomingAppointments.map((apt) => (
                  <div key={apt.id} className="flex items-center justify-between mb-6 last:mb-0 pb-6 last:pb-0 border-b last:border-0">
                    <div className="flex items-center">
                      <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 font-bold">
                        {apt.name.charAt(0)}
                      </div>
                      <div className="ml-4">
                        <h3 className="font-medium text-gray-800">{apt.name}</h3>
                        <p className="text-sm text-gray-500">{apt.species} • {apt.owner}</p>
                        <div className="flex mt-1">
                          <span 
                            className="text-xs px-2 py-0.5 rounded-full text-white mr-2"
                            style={{
                              backgroundColor: apt.type === 'Surgery' ? '#EF4444' : 
                                             apt.type === 'Telehealth' ? '#0EA5E9' : '#10B981'
                            }}
                          >
                            {apt.type}
                          </span>
                          <span className="text-xs text-gray-500">{apt.time}</span>
                        </div>
                      </div>
                    </div>
                    <button 
                      className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm shadow-sm hover:bg-blue-600"
                      onClick={() => {
                        setSelectedAppointment(apt);
                        setCurrentView('appointment-detail');
                      }}
                    >
                      View
                    </button>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Recent messages */}
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-lg font-semibold text-gray-800">Recent Messages</h2>
                <button 
                  className="text-blue-600 text-sm flex items-center"
                  onClick={() => handleTabClick('messages')}
                >
                  View All <ChevronRight size={16} />
                </button>
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-6 pb-6 border-b">
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-500 font-bold">
                      S
                    </div>
                    <div className="ml-4">
                      <h3 className="font-medium text-gray-800">Sarah Johnson</h3>
                      <p className="text-sm text-gray-500">Re: Bella's medication</p>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">10:30 AM</span>
                </div>
                <div className="flex items-center justify-between mb-6 pb-6 border-b">
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-500 font-bold">
                      M
                    </div>
                    <div className="ml-4">
                      <h3 className="font-medium text-gray-800">Michael Brown</h3>
                      <p className="text-sm text-gray-500">Question about Charlie's diet</p>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">Yesterday</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full bg-yellow-100 flex items-center justify-center text-yellow-500 font-bold">
                      E
                    </div>
                    <div className="ml-4">
                      <h3 className="font-medium text-gray-800">Emily Wilson</h3>
                      <p className="text-sm text-gray-500">Luna's post-surgery care</p>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">May 10</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Right column - Health certificates and quick actions */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow overflow-hidden mb-6">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-800">Health Certificates</h2>
              </div>
              <div className="p-6">
                {recentHealthCerts.map((cert) => (
                  <div key={cert.id} className="mb-4 pb-4 border-b last:border-0 last:mb-0 last:pb-0">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium text-gray-800">{cert.pet}</h3>
                        <p className="text-sm text-gray-500">{cert.type}</p>
                        <p className="text-xs text-gray-500">{cert.destinations}</p>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        cert.status === 'Completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {cert.status}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{cert.date}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-800">Quick Actions</h2>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-2 gap-4">
                  <button className="p-4 bg-blue-50 rounded-lg flex flex-col items-center justify-center hover:bg-blue-100">
                    <Calendar className="h-6 w-6 text-blue-500 mb-2" />
                    <span className="text-sm font-medium text-gray-700">Schedule</span>
                  </button>
                  <button className="p-4 bg-green-50 rounded-lg flex flex-col items-center justify-center hover:bg-green-100">
                    <MessageCircle className="h-6 w-6 text-green-500 mb-2" />
                    <span className="text-sm font-medium text-gray-700">Message</span>
                  </button>
                  <button className="p-4 bg-purple-50 rounded-lg flex flex-col items-center justify-center hover:bg-purple-100">
                    <FileText className="h-6 w-6 text-purple-500 mb-2" />
                    <span className="text-sm font-medium text-gray-700">Records</span>
                  </button>
                  <button className="p-4 bg-yellow-50 rounded-lg flex flex-col items-center justify-center hover:bg-yellow-100">
                    <Pill className="h-6 w-6 text-yellow-500 mb-2" />
                    <span className="text-sm font-medium text-gray-700">Prescribe</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Appointments View
  const AppointmentsContent = () => {
    // State for collapsible sections
    const [upcomingExpanded, setUpcomingExpanded] = useState(true);
    const [completedExpanded, setCompletedExpanded] = useState(false);
    
    // Ensure filter is working 
    const filteredAppointments = filter === 'all' 
      ? allAppointments 
      : allAppointments.filter(apt => apt.type.toLowerCase() === filter.toLowerCase());
    
    // Get current time for determining past appointments
    const currentTime = new Date();
    currentTime.setHours(currentTime.getHours() - 4); // This makes most appointments in the future for demo
    
    // Function to check if appointment time has passed
    const isAppointmentPast = (time) => {
      const [hourMin, period] = time.split(' ');
      const [hour, minute] = hourMin.split(':');
      
      let appointmentHour = parseInt(hour);
      if (period === 'PM' && appointmentHour !== 12) {
        appointmentHour += 12;
      } else if (period === 'AM' && appointmentHour === 12) {
        appointmentHour = 0;
      }
      
      const appointmentDate = new Date();
      appointmentDate.setHours(appointmentHour, parseInt(minute), 0, 0);
      
      return appointmentDate < currentTime;
    };
    
    // Separate appointments into upcoming and completed
    const upcomingAppointments = filteredAppointments.filter(apt => !isAppointmentPast(apt.time));
    const completedAppointments = filteredAppointments.filter(apt => isAppointmentPast(apt.time));
    
    // Component for collapsible section header
    const SectionHeader = ({ title, count, isExpanded, toggleExpanded, bgColor }) => (
      <div 
        className={`px-4 py-3 flex justify-between items-center cursor-pointer ${bgColor}`}
        onClick={toggleExpanded}
      >
        <div className="flex items-center">
          <h2 className="font-bold text-lg text-gray-800">{title}</h2>
          <span className="ml-2 px-2 py-0.5 bg-gray-200 text-gray-800 rounded-full text-sm font-medium">
            {count}
          </span>
        </div>
        <div className="text-gray-600">
          {isExpanded ? "▼" : "►"}
        </div>
      </div>
    );
    
    return (
      <div className="max-w-6xl mx-auto">
        <h1 className="text-2xl font-semibold text-gray-800 mb-6">
          Appointments - {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
        </h1>
        
        <div className="bg-white rounded-lg shadow overflow-hidden mb-6">
          <div className="px-4 py-3 border-b border-gray-200 flex justify-between items-center">
            <h2 className="font-bold text-xl text-gray-800">
              All Appointments
            </h2>
            <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
              {filteredAppointments.length} Total
            </span>
          </div>
          
          {/* Filter buttons - explicitly styled for visibility */}
          <div className="px-4 pt-3 pb-2 border-b border-gray-200">
            <div className="flex space-x-2">
              <button 
                className={`px-3 py-1.5 rounded-md text-sm font-medium shadow-sm ${filter === 'all' ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-700'}`}
                onClick={() => setFilter('all')}
              >
                All
              </button>
              <button 
                className={`px-3 py-1.5 rounded-md text-sm font-medium shadow-sm ${filter === 'surgery' ? 'bg-red-500 text-white' : 'bg-red-100 text-red-700'}`}
                onClick={() => setFilter('surgery')}
              >
                Surgeries
              </button>
              <button 
                className={`px-3 py-1.5 rounded-md text-sm font-medium shadow-sm ${filter === 'telehealth' ? 'bg-blue-500 text-white' : 'bg-blue-100 text-blue-700'}`}
                onClick={() => setFilter('telehealth')}
              >
                Telehealth
              </button>
              <button 
                className={`px-3 py-1.5 rounded-md text-sm font-medium shadow-sm ${filter === 'in-person' ? 'bg-green-500 text-white' : 'bg-green-100 text-green-700'}`}
                onClick={() => setFilter('in-person')}
              >
                In-person
              </button>
            </div>
          </div>
          
          {/* Upcoming Appointments Section */}
          <div className="border-b border-gray-200">
            <SectionHeader 
              title="Upcoming Appointments" 
              count={upcomingAppointments.length}
              isExpanded={upcomingExpanded}
              toggleExpanded={() => setUpcomingExpanded(!upcomingExpanded)}
              bgColor="bg-white"
            />
            
            {upcomingExpanded && (
              <div className="p-4">
                {upcomingAppointments.length > 0 ? (
                  upcomingAppointments.map(apt => (
                    <div 
                      key={apt.id} 
                      className="border border-gray-200 rounded-lg p-4 mb-4 hover:bg-gray-50"
                    >
                      <div className="flex justify-between">
                        <div>
                          <div className="flex items-center">
                            <h3 className="font-medium text-gray-800">{apt.name}</h3>
                            <span className="mx-2 text-xs text-gray-400">•</span>
                            <span className="text-xs text-gray-500">{apt.species} - {apt.breed}</span>
                          </div>
                          <p className="text-sm text-gray-600 mt-1">Owner: {apt.owner}</p>
                          <p className="text-sm text-gray-600">Reason: {apt.reason}</p>
                          <div className="flex items-center mt-1 space-x-2">
                            <span 
                              className="inline-block text-xs rounded-full px-2 py-0.5 text-white"
                              style={{ 
                                backgroundColor: apt.type === 'Telehealth' ? '#0EA5E9' : 
                                              apt.type === 'Surgery' ? '#EF4444' : '#10B981'
                              }}
                            >
                              {apt.type}
                            </span>
                            <span className="text-xs text-gray-500">{apt.doctor}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="font-medium text-gray-700">{apt.time}</span>
                          <div className="flex flex-col items-end mt-2">
                            <button 
                              className="px-4 py-1.5 rounded text-sm font-medium text-white bg-blue-500 shadow-sm w-24"
                              onClick={() => {
                                setSelectedAppointment(apt);
                                setCurrentView('appointment-detail');
                              }}
                            >
                              View
                            </button>
                            <button 
                              className="mt-1 text-xs font-medium text-blue-600 hover:text-blue-800 hover:underline"
                              onClick={() => alert(`Rescheduling appointment for ${apt.name}`)}
                            >
                              Reschedule
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-500 text-center py-4">No upcoming appointments</p>
                )}
              </div>
            )}
          </div>
          
          {/* Completed Appointments Section */}
          <div>
            <SectionHeader 
              title="Completed Appointments" 
              count={completedAppointments.length}
              isExpanded={completedExpanded}
              toggleExpanded={() => setCompletedExpanded(!completedExpanded)}
              bgColor="bg-gray-50"
            />
            
            {completedExpanded && (
              <div className="p-4 bg-gray-50">
                {completedAppointments.length > 0 ? (
                  completedAppointments.map(apt => (
                    <div 
                      key={apt.id} 
                      className="border border-gray-200 rounded-lg p-4 mb-4 hover:bg-gray-100 bg-white"
                    >
                      <div className="flex justify-between">
                        <div>
                          <div className="flex items-center">
                            <h3 className="font-medium text-gray-800">{apt.name}</h3>
                            <span className="mx-2 text-xs text-gray-400">•</span>
                            <span className="text-xs text-gray-500">{apt.species} - {apt.breed}</span>
                          </div>
                          <p className="text-sm text-gray-600 mt-1">Owner: {apt.owner}</p>
                          <p className="text-sm text-gray-600">Reason: {apt.reason}</p>
                          <div className="flex items-center mt-1 space-x-2">
                            <span className="inline-block text-xs rounded-full px-2 py-0.5 text-white bg-gray-600">
                              Completed
                            </span>
                            <span className="text-xs text-gray-500">{apt.doctor}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="font-medium text-gray-700">{apt.time}</span>
                          <div className="flex flex-col items-end mt-2">
                            <button 
                              className="px-4 py-1.5 rounded text-sm font-medium text-white bg-blue-500 shadow-sm w-24"
                              onClick={() => {
                                setSelectedAppointment(apt);
                                setCurrentView('appointment-detail');
                              }}
                            >
                              Review
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-500 text-center py-4">No completed appointments</p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  // Appointment Detail Page
  const AppointmentDetailPage = () => {
    // Mock patient data
    const patientData = {
      name: selectedAppointment.name,
      species: selectedAppointment.species,
      breed: selectedAppointment.breed,
      age: '3 years',
      weight: '21.5 kg',
      lastVisit: '2024-12-15',
      owner: selectedAppointment.owner,
      phone: '(555) 123-4567',
      email: `${selectedAppointment.owner.toLowerCase().replace(' ', '.')}@email.com`,
      allergies: ['Penicillin'],
      microchip: '985112345678903',
      neutered: true,
      medications: [
        { name: 'Apoquel', dosage: '5.4mg', frequency: 'Once daily', startDate: '2024-12-15', endDate: '2025-05-15' }
      ],
      vaccinations: [
        { name: 'Rabies', date: '2024-07-10', due: '2025-07-10' },
        { name: 'DHPP', date: '2024-07-10', due: '2025-07-10' },
        { name: 'Bordetella', date: '2024-01-15', due: '2025-01-15' }
      ],
      pastAppointments: [
        { date: '2024-12-15', reason: 'Annual check-up', diagnosis: 'Healthy, with mild seasonal allergies', doctor: 'Dr. Roberts' },
        { date: '2024-06-30', reason: 'Limping on right front leg', diagnosis: 'Mild sprain, rest recommended', doctor: 'Dr. Chen' },
        { date: '2023-07-10', reason: 'Vaccinations', diagnosis: 'Healthy', doctor: 'Dr. Roberts' }
      ]
    };
    
    // Determine if this is a telehealth appointment
    const isTelehealth = selectedAppointment.type === 'Telehealth';
    const isPhoneAppointment = false; // Placeholder - would be determined by appointment type
    const isChatAppointment = false; // Placeholder - would be determined by appointment type

    // AI recommendations based on appointment reason
    const aiRecommendations = getAiRecommendations();
    
    // Back button handler
    const handleBack = () => {
      setSelectedAppointment(null);
      setCurrentView('appointments');
    };
    
    // Function to format date for display
    const formatDate = (dateString) => {
      const options = { year: 'numeric', month: 'short', day: 'numeric' };
      return new Date(dateString).toLocaleDateString('en-US', options);
    };
    
    return (
      <div className="max-w-7xl mx-auto">
        {/* Header with back button */}
        <div className="flex items-center mb-6">
          <button 
            className="mr-4 px-3 py-1.5 rounded text-sm font-medium text-gray-600 border border-gray-300 hover:bg-gray-50 shadow-sm flex items-center"
            onClick={handleBack}
          >
            <ArrowLeft size={16} className="mr-1" /> Back to Appointments
          </button>
          <h1 className="text-2xl font-semibold text-gray-800">
            {selectedAppointment.name} - {selectedAppointment.reason}
          </h1>
        </div>
        
        {/* Main content grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Left column - Patient info */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow overflow-hidden mb-4">
              <div className="px-4 py-3 bg-blue-50 border-b border-blue-100">
                <h2 className="font-bold text-lg text-blue-800">Patient Information</h2>
              </div>
              
              <div className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium text-lg text-gray-900">{patientData.name}</h3>
                    <p className="text-gray-500">{patientData.species} - {patientData.breed}</p>
                  </div>
                  <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs">
                    {patientData.microchip ? 'Microchipped' : 'No Microchip'}
                  </span>
                </div>
                
                <div className="mt-4 grid grid-cols-2 gap-2">
                  <div>
                    <p className="text-xs text-gray-500">Age</p>
                    <p className="font-medium">{patientData.age}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Weight</p>
                    <p className="font-medium">{patientData.weight}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Gender</p>
                    <p className="font-medium">{patientData.neutered ? 'Neutered Male' : 'Male'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Last Visit</p>
                    <p className="font-medium">{patientData.lastVisit}</p>
                  </div>
                </div>
                
                <div className="mt-4">
                  <p className="text-xs text-gray-500">Owner</p>
                  <p className="font-medium">{patientData.owner}</p>
                  <p className="text-sm text-gray-500">{patientData.phone}</p>
                  <p className="text-sm text-gray-500">{patientData.email}</p>
                </div>
                
                <div className="mt-4">
                  <p className="text-xs text-gray-500">Allergies</p>
                  {patientData.allergies.length > 0 ? (
                    <div className="flex flex-wrap gap-1 mt-1">
                      {patientData.allergies.map((allergy, index) => (
                        <span key={index} className="px-2 py-0.5 bg-red-100 text-red-700 rounded text-xs">
                          {allergy}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="font-medium">None known</p>
                  )}
                </div>
              </div>
            </div>
            
            {/* Current Medications */}
            <div className="bg-white rounded-lg shadow overflow-hidden mb-4">
              <div className="px-4 py-3 bg-blue-50 border-b border-blue-100">
                <h2 className="font-bold text-lg text-blue-800">Current Medications</h2>
              </div>
              
              <div className="p-4">
                {patientData.medications.length > 0 ? (
                  patientData.medications.map((med, index) => (
                    <div key={index} className="mb-3 pb-3 border-b border-gray-100 last:border-0 last:mb-0 last:pb-0">
                      <div className="flex justify-between">
                        <h3 className="font-medium text-gray-900">{med.name}</h3>
                        <span className="text-xs text-gray-500">
                          {med.startDate} - {med.endDate}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">{med.dosage}, {med.frequency}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-500">No current medications</p>
                )}
              </div>
            </div>
            
            {/* Vaccination Records */}
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="px-4 py-3 bg-blue-50 border-b border-blue-100">
                <h2 className="font-bold text-lg text-blue-800">Vaccination Records</h2>
              </div>
              
              <div className="p-4">
                {patientData.vaccinations.length > 0 ? (
                  patientData.vaccinations.map((vax, index) => (
                    <div key={index} className="mb-3 pb-3 border-b border-gray-100 last:border-0 last:mb-0 last:pb-0">
                      <div className="flex justify-between">
                        <h3 className="font-medium text-gray-900">{vax.name}</h3>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${new Date(vax.due) < new Date() ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                          {new Date(vax.due) < new Date() ? 'Overdue' : 'Current'}
                        </span>
                      </div>
                      <div className="flex justify-between mt-1">
                        <span className="text-xs text-gray-500">Given: {vax.date}</span>
                        <span className="text-xs text-gray-500">Due: {vax.due}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-500">No vaccination records</p>
                )}
              </div>
            </div>
          </div>
          
          {/* Middle and right columns - Appointment details and AI features */}
          <div className="lg:col-span-2">
            {/* Appointment details card */}
            <div className="bg-white rounded-lg shadow overflow-hidden mb-4">
              <div className="px-4 py-3 bg-blue-50 border-b border-blue-100 flex justify-between items-center">
                <h2 className="font-bold text-lg text-blue-800">Appointment Details</h2>
                <div className="flex items-center">
                  <span 
                    className="inline-block text-xs rounded-full px-2 py-1 text-white mr-2"
                    style={{ 
                      backgroundColor: 
                        selectedAppointment.type === 'Telehealth' ? '#0EA5E9' : 
                        selectedAppointment.type === 'Surgery' ? '#EF4444' : 
                        '#10B981' 
                    }}
                  >
                    {selectedAppointment.type}
                  </span>
                  <span className="text-sm font-medium text-gray-700">{selectedAppointment.time}</span>
                </div>
              </div>
              
              <div className="p-4">
                <div className="mb-4">
                  <h3 className="text-sm text-gray-500">Reason for Visit</h3>
                  <p className="text-base font-medium">{selectedAppointment.reason}</p>
                </div>
                
                <div className="mb-4">
                  <h3 className="text-sm text-gray-500">Care Provider</h3>
                  <p className="text-base font-medium">{selectedAppointment.doctor}</p>
                </div>
                
                {/* Telehealth specific controls */}
                {isTelehealth && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <h3 className="font-medium text-blue-800 mb-2">Telehealth Appointment</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      This is a virtual appointment. You can connect with the patient using one of the following methods:
                    </p>
                    
                    <button 
                      className="w-full py-2 px-4 bg-blue-500 text-white font-medium rounded-lg shadow-sm hover:bg-blue-600 flex items-center justify-center"
                    >
                      <Video className="h-5 w-5 mr-2" />
                      Start Video Call
                    </button>
                    
                    <div className="text-xs text-gray-500 mt-2 text-center">
                      Patient will receive notification to join the call
                    </div>
                  </div>
                )}
                
                {/* Phone appointment specific info */}
                {isPhoneAppointment && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <h3 className="font-medium text-blue-800 mb-2">Phone Appointment</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      Please call the patient at the appointment time:
                    </p>
                    
                    <div className="text-xl font-medium text-center text-blue-800">
                      {patientData.phone}
                    </div>
                  </div>
                )}
                
                {/* Chat appointment specific info */}
                {isChatAppointment && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <h3 className="font-medium text-blue-800 mb-2">Chat Appointment</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      You can chat with the patient directly:
                    </p>
                    
                    <button 
                      className="w-full py-2 px-4 bg-blue-500 text-white font-medium rounded-lg shadow-sm hover:bg-blue-600 flex items-center justify-center"
                    >
                      <MessageSquare className="h-5 w-5 mr-2" />
                      Start Chat Session
                    </button>
                  </div>
                )}
              </div>
            </div>
            
            {/* AI Voice Dictation */}
            <div className="bg-white rounded-lg shadow overflow-hidden mb-4">
              <div className="px-4 py-3 bg-green-50 border-b border-green-100">
                <h2 className="font-bold text-lg text-green-800">AI Voice Dictation</h2>
              </div>
              
              <div className="p-4">
                {!aiTranscription ? (
                  <div className="text-center py-6">
                    {isRecording ? (
                      <div>
                        <div className="animate-pulse flex justify-center mb-4">
                          <span className="inline-block h-3 w-3 rounded-full bg-red-500 mr-1"></span>
                          <span className="inline-block h-3 w-3 rounded-full bg-red-500 mr-1 animate-bounce"></span>
                          <span className="inline-block h-3 w-3 rounded-full bg-red-500"></span>
                        </div>
                        <p className="text-gray-500 mb-4">Recording and analyzing conversation...</p>
                        <button 
                          className="px-4 py-2 bg-red-500 text-white font-medium rounded-lg shadow-sm hover:bg-red-600"
                          onClick={stopVoiceDictation}
                        >
                          Stop Recording
                        </button>
                      </div>
                    ) : (
                      <div>
                        <p className="text-gray-500 mb-4">Start recording to capture conversation and generate AI summaries</p>
                        <button 
                          className="px-4 py-2 bg-green-500 text-white font-medium rounded-lg shadow-sm hover:bg-green-600"
                          onClick={startVoiceDictation}
                        >
                          Start Recording
                        </button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div>
                    <div className="mb-4">
                      <h3 className="font-medium text-gray-700 mb-2">Conversation Transcript</h3>
                      <div className="bg-gray-50 p-3 rounded-lg text-sm whitespace-pre-line">
                        {aiTranscription.transcription}
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <h3 className="font-medium text-gray-700 mb-2">AI Generated Summary</h3>
                      <div className="bg-green-50 p-3 rounded-lg border border-green-100">
                        <p className="text-sm font-medium mb-2">{aiTranscription.summary.highlevel}</p>
                        <p className="text-sm">{aiTranscription.summary.detailed}</p>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="font-medium text-gray-700 mb-2">AI Suggested Diagnoses</h3>
                      <div className="flex flex-wrap gap-2">
                        {aiTranscription.diagnoses.map((diagnosis, index) => (
                          <span key={index} className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm">
                            {diagnosis}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="mt-4 text-right">
                      <button 
                        className="px-4 py-2 bg-blue-500 text-white font-medium rounded-lg shadow-sm hover:bg-blue-600"
                      >
                        Use for Charting
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* AI Recommendations */}
            <div className="bg-white rounded-lg shadow overflow-hidden mb-4">
              <div className="px-4 py-3 bg-purple-50 border-b border-purple-100">
                <h2 className="font-bold text-lg text-purple-800">AI Treatment Recommendations</h2>
              </div>
              
              <div className="p-4">
                <div className="mb-4">
                  <p className="text-sm text-gray-500 italic">Based on appointment reason: {selectedAppointment.reason}</p>
                </div>
                
                <ul className="space-y-2">
                  {aiRecommendations.map((rec, index) => (
                    <li key={index} className="flex items-start">
                      <span className="inline-block h-5 w-5 rounded-full bg-purple-100 text-purple-800 flex items-center justify-center mr-2 flex-shrink-0 text-xs">
                        {index + 1}
                      </span>
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="mt-4">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search medical knowledge base..."
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                    <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                  </div>
                </div>
              </div>
            </div>
            
            {/* Medical History */}
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="px-4 py-3 bg-blue-50 border-b border-blue-100">
                <h2 className="font-bold text-lg text-blue-800">Medical History</h2>
              </div>
              
              <div className="p-4">
                {patientData.pastAppointments.length > 0 ? (
                  <div className="space-y-4">
                    {patientData.pastAppointments.map((apt, index) => (
                      <div key={index} className="border-b border-gray-100 pb-4 last:border-0">
                        <div className="flex justify-between mb-1">
                          <h3 className="font-medium">{apt.date}</h3>
                          <span className="text-sm text-gray-500">{apt.doctor}</span>
                        </div>
                        <p className="text-sm text-gray-700 mb-1"><strong>Reason:</strong> {apt.reason}</p>
                        <p className="text-sm text-gray-700"><strong>Diagnosis:</strong> {apt.diagnosis}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No previous appointments</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Generic landing component for not-yet-implemented tabs
  const GenericPageContent = ({ title }) => (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-2xl font-semibold text-gray-800 mb-6">{title}</h1>
      <div className="bg-white rounded-lg shadow p-6 text-center">
        <p className="text-gray-500">This feature is coming soon in the next version of KleoVet.</p>
        <button 
          className="mt-4 px-4 py-2 bg-blue-500 text-white font-medium rounded-lg shadow-sm hover:bg-blue-600"
          onClick={() => handleTabClick('dashboard')}
        >
          Return to Dashboard
        </button>
      </div>
    </div>
  );
  
  // Main application renderer
  return (
    <div className="min-h-screen bg-gray-100">
      {!isLoggedIn ? (
        <LoginPage />
      ) : (
        <div className="flex flex-col h-screen">
          <Header />
          <div className="flex flex-1 overflow-hidden">
            <Sidebar />
            <main className="flex-1 p-6 overflow-y-auto">
              {currentView === 'dashboard' && <Dashboard />}
              {currentView === 'appointments' && <AppointmentsContent />}
              {currentView === 'appointment-detail' && selectedAppointment && <AppointmentDetailPage />}
              {currentView === 'patients' && <GenericPageContent title="Patients" />}
              {currentView === 'telehealth' && <GenericPageContent title="Telehealth" />}
              {currentView === 'messages' && <GenericPageContent title="Messages" />}
              {currentView === 'health-certs' && <GenericPageContent title="Health Certificates" />}
              {currentView === 'records' && <GenericPageContent title="Records" />}
              {currentView === 'settings' && <GenericPageContent title="Settings" />}
            </main>
          </div>
        </div>
      )}
    </div>
  );
};

export default KleoVet;